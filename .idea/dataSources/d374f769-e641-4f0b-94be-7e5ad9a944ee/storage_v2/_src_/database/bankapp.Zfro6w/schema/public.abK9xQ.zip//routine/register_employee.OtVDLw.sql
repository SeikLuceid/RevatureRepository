create procedure register_employee(p_username text, p_password text, p_is_employee boolean, p_last_name text)
    language plpgsql
as
$$
DECLARE
    v_user_id integer;
BEGIN
    INSERT INTO users (username, password, is_employee)
    VALUES(p_username, pgcrypto.crypt(p_password, pgcrypto.gen_salt('bf')), p_is_employee);

    SELECT user_id INTO v_user_id FROM users 
	WHERE username = p_username;

    INSERT INTO employees (user_id, last_name)
    VALUES( v_user_id, p_last_name);
END;
$$;

alter procedure register_employee(text, text, boolean, text) owner to postgres;

