create function ssn_exists(p_ssn_text text) returns boolean
    language plpgsql
as
$$
DECLARE
    rec RECORD;
BEGIN
    SELECT ssn INTO rec FROM customers WHERE ssn = p_ssn_text;

    IF NOT FOUND THEN
        RETURN false;
    ELSE
        RETURN true;
    END IF;
END;
$$;

alter function ssn_exists(text) owner to bankapp;

