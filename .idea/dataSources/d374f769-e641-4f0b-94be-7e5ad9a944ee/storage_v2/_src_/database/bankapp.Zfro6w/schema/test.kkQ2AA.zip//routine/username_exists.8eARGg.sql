create function username_exists(para_username text) returns boolean
    language plpgsql
as
$$
DECLARE
	rec RECORD;
BEGIN
	SELECT username INTO rec FROM users WHERE username = para_username;

	IF NOT FOUND THEN
		RETURN false;
	ELSE
		RETURN true;
	END IF;
END;
$$;

alter function username_exists(text) owner to postgres;

