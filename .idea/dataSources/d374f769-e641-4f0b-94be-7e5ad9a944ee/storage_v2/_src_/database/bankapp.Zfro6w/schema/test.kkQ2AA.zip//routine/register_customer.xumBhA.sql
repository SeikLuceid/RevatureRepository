create procedure register_customer(p_username text, p_password text, p_first_name text, p_last_name text, p_ssn_text text)
    language plpgsql
as
$$
DECLARE
    v_user_id integer;
BEGIN
    INSERT INTO users (username, password)
    VALUES(p_username, pgcrypto.crypt(p_password, pgcrypto.gen_salt('bf')));

    SELECT user_id INTO v_user_id FROM users WHERE username = p_username;

    INSERT INTO customers (first_name, last_name, ssn, user_id)
    VALUES(p_first_name, p_last_name, p_ssn_text, v_user_id);
END;
$$;

alter procedure register_customer(text, text, text, text, text) owner to postgres;

