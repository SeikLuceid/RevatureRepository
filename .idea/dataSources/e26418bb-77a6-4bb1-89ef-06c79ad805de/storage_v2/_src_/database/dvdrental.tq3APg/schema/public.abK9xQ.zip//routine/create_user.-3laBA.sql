create procedure create_user(new_user_name text, new_password text, new_first_name text, new_last_name text, new_ssn integer)
    language plpgsql
as
$$
BEGIN
        INSERT INTO accounts (user_name, password, first_name, last_name, ssn)
        VALUES (new_user_name, new_password, new_first_name, new_last_name, new_ssn);
    END;
$$;

alter procedure create_user(text, text, text, text, integer) owner to postgres;

