create function swap(INOUT x integer, INOUT y integer) returns record
    language plpgsql
as
$$
BEGIN
    SELECT x, y INTO y, x;
END;
$$;

alter function swap(inout integer, inout integer) owner to postgres;

