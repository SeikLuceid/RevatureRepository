create function get_film_stat(OUT min_len integer, OUT max_len integer, OUT avg_len numeric) returns record
    language plpgsql
as
$$
BEGIN
    SELECT 
           MIN(length), 
           MAX(length), 
           AVG(length)::NUMERIC(5, 1)
    INTO min_len, max_len, avg_len
    FROM film;
END;
$$;

alter function get_film_stat(out integer, out integer, out numeric) owner to postgres;

