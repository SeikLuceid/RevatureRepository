create view customer_master(id, name, address, "zip code", phone, city, country, notes, sid) as
SELECT cu.customer_id                                           AS id,
       (cu.first_name::text || ' '::text) || cu.last_name::text AS name,
       a.address,
       a.postal_code                                            AS "zip code",
       a.phone,
       city.city,
       country.country,
       CASE
           WHEN cu.activebool THEN 'active'::text
           ELSE ''::text
           END                                                  AS notes,
       cu.store_id                                              AS sid
FROM customer cu
         JOIN address a USING (address_id)
         JOIN city USING (city_id)
         JOIN country USING (country_id);

alter table customer_master
    owner to postgres;

