create function check_password(p_username text, p_password text) returns integer
    language plpgsql
as
$$
DECLARE v_user_id INT := -1;
BEGIN
    SELECT user_id INTO v_user_id FROM users WHERE username = p_username AND password = crypt(p_password, password);
    RETURN v_user_id;
END;
$$;

alter function check_password(text, text) owner to bankapp;

