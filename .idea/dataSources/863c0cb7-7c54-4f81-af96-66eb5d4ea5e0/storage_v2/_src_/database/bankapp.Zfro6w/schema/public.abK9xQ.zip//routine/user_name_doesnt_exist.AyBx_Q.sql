create function user_name_doesnt_exist(target_username character varying) returns boolean
    language plpgsql
as
$$
DECLARE
        rec RECORD;
    BEGIN
        SELECT username INTO rec FROM users WHERE username = target_username;
        IF NOT FOUND THEN
            RETURN true;
        ELSE
            RETURN false;
        end if;
    END;
$$;

alter function user_name_doesnt_exist(varchar) owner to bankapp;

