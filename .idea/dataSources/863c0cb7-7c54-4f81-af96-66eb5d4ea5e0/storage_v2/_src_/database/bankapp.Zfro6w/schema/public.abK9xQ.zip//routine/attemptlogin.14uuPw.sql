create function attemptlogin(login text, pass text, OUT isvalid boolean) returns boolean
    language plpgsql
as
$$
DECLARE
	matching_users integer;
BEGIN
	SELECT COUNT(*)
	INTO matching_users
	FROM users
	WHERE email = login
	AND password = crypt(pass, password);
	
	IF(matching_users > 0) THEN
		isvalid = true;
	END IF;
	
	return;
END;
$$;

alter function attemptlogin(text, text, out boolean) owner to bankapp;

